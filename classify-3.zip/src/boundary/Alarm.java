package boundary;

public class Alarm {
	public void on() {
		System.out.println("alarm is on!");
	}
}
