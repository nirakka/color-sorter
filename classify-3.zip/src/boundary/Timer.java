package boundary;

public class Timer {

	private int counter=0;
	private int limit=0;
	private boolean timeout=false;
	public void setTimeout(int t) {this.limit = t;};
	
	public void reset() {counter = 0 ;}
}
