package main;

import controller.ClassificationController;

public class UI {

    static ClassificationController c;
	public static void main(String[] args) {
		
		c = new ClassificationController();
		c.run();

	}
}
