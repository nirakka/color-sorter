package controller;

import boundary.Alarm;
import boundary.Display;
import boundary.LightSensor;
import boundary.Selector;
import boundary.Timer;
import boundary.WeightSensor;
import entity.ProductPool;
import utility.ColorDef;
import utility.Product;
import utility.RGB;
import utility.Range;

public class ClassificationController {
	// クラス図に出現するオブジェクトをインスタンス化
	private WeightSensor weightSensor;
	private LightSensor lightSensor;
	private Examiner examiner;
	private Selector selector;
	private ProductPool pool;
	private Display counter;
	private Timer timer;
	private Alarm alarm;
	
	private Range[] WRange = new Range[] { new Range(50, 100) };
	private ColorDef[] ColorDefs = new ColorDef[] { 
            new ColorDef(new Range(200, 300), new Range(0, 50), new Range(0, 50), 1), // red
            new ColorDef(new Range(0, 50), new Range(200, 300), new Range(0, 50), 2), // green
            new ColorDef(new Range(0, 50), new Range(0, 50), new Range(200, 300), 3), // blue
	};
	
	
	// 数字に意味はない
	private Product[] products1 = new Product[] {
			new Product( 30, new RGB(100, 100, 100)),
			new Product( 50, new RGB(200, 200, 200)),
	};

	public ClassificationController() {
		examiner = new Examiner(WRange, ColorDefs); 
		selector = new Selector();
		weightSensor = new WeightSensor();
		lightSensor = new LightSensor();
		pool = new ProductPool(products1);
		counter = new Display();
		timer = new Timer();
		alarm = new Alarm();
	}
	
	public void run() {
		while (!pool.isEmpty()) {
			classify(); //UC:[製品を分類する]に対応
			boolean b = counter.isPrepared(); //事前条件
			if (b) 
				ship();     //UC:[製品を出荷する]に対応
		}
	}
	
	private boolean received=false;
	private boolean timeout=false;
	
	public void ship() {  
		timer.setTimeout(100);
		//addReq() 出荷要求送信
		
		while(true) {
			//出荷完了通知を受け取るまで
			if (received) {
				timer.reset();
				finish();
				break;
			}	else if (timeout) {
				alarm.on();
				break;
			}
			
			//
		}
	}

	private void finish() {
		// removeReq() 出荷要求取り下げ
	}

	public void classify() {
		Product p = pool.getProduct();
		int w = weightSensor.getWeight(p);
		RGB rgb = lightSensor.getRGB(p);
		int lane = examiner.examine(w, rgb);
		selector.select(lane);
		counter.inc(lane);
		System.out.println("counter:" + counter);
	}

	public void setExaminer(Range[] r, ColorDef[] c) {
		examiner = new Examiner(r, c);
	}

	public Selector getSelector() {
		return selector;
	}

	public void setProductPool(Product[] products) {
		pool.setProducts(products);
	}
	
}